package MojeKlasy;

public class Klient {
    protected String nazwa;
    protected int nrTelefonu;
    protected String kraj;
    protected double kapital;

    public Klient(String nazwa, int nrTelefonu, String kraj, double kapital) {
        this.nazwa = nazwa;
        this.nrTelefonu = nrTelefonu;
        this.kraj = kraj;
        this.kapital = kapital;
    }
    public double PoliczKapitał() {
        return PoliczKapitał(12);

    }

    public double PoliczKapitał(int miesiace) {
        double odsetki = 0.03;
        double oprocentowanie = 1 + odsetki;
        double wynik = kapital * Math.pow(oprocentowanie, miesiace);
        return wynik;
    }
}
