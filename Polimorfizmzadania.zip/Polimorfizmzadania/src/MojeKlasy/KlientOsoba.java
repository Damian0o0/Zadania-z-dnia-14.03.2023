package MojeKlasy;
import java.time.LocalDate;

public class KlientOsoba extends Klient {
    private String Imie;
    private String Nazwisko;
    private LocalDate Data_urodzenia;
    public KlientOsoba(String Imie, String Nazwisko, LocalDate Data_urodzenia, int nrTelefonu, String kraj, double kapital) {
        super("osoba prawna", nrTelefonu, kraj, kapital);
        this.Imie = Imie;
        this.Nazwisko = Nazwisko;
        this.Data_urodzenia = Data_urodzenia;
    }

    public double PoliczKapitał2(int miesiace) {
        double odsetki = 0.02;
        double oprocentowanie = 1 + odsetki;
        double wynik = kapital * Math.pow(oprocentowanie, miesiace);
        return wynik;
    }
}