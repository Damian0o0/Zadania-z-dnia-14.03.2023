import MojeKlasy.Klient;
import java.time.LocalDate;
import MojeKlasy.KlientOsoba;

public class Main {
    public static void main(String[] args) {
        Klient klient1 = new Klient("Neymar Da Silva", 123142144, "Polska" ,1000);
        System.out.println(klient1.toString());
        klient1.PoliczKapitał();
        System.out.println("Kapitał po paru miesiącach: " + klient1.PoliczKapitał(2));

        KlientOsoba klient = new KlientOsoba("Neymar Da Silva", "Santos Junior", LocalDate.of(2005, 6, 22),
                123456789, "Polska", 1000);
        klient.PoliczKapitał2(2);
        System.out.println(klient.PoliczKapitał2(2));
    }
}